using System;

namespace Listjj.Infrastructure.ViewModels
{
    public class FileViewModel: FileSimpleViewModel
    {
        public string B64Bytes { get; set; }
    }
}