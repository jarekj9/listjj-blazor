﻿namespace Listjj.Infrastructure
{
    public class Class1
    {

    }
}